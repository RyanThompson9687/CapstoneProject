To run locally: 


Machine must have Python installed locally
Recommended to run in a python virtual environment (optional)

open CMD

activate python virtual environment (if applicable)

cd to the directory where the src folder is located

run the following command to open a localhost server
	python -m http.server

in the browser, enter http://localhost:8000

